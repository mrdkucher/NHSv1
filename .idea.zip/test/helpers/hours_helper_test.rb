require 'test_helper'

class HoursHelperTest < ActionView::TestCase
end

require 'test_helper'

class HoursControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end

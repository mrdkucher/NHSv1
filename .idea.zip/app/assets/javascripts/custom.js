/* var main = function() {
  $('#click').click(function() {
    $('#signin').toggle();
  });
}

$(document).ready(main);*/